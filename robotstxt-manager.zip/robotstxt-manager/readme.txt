=== Robots.txt Manager ===
Plugin Name: Robots.txt Manager
Contributors: Chris Winters
Tags: robotstxt, robots.txt, robots, robot, spiders, virtual, search, google, seo
Requires at least: 4.9
Tested up to: 6.1.1
Stable tag: 2.0.0
License: GNU GPLv3
License URI: /LICENSE
