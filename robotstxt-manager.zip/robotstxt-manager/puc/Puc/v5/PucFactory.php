<?php

namespace YahnisElsts\PluginUpdateChecker\v5;

if ( !class_exists(PucFactory::class, false) ):

	class PucFactory extends \YahnisElsts\PluginUpdateChecker\v5p0\PucFactory {
	}

endif;
